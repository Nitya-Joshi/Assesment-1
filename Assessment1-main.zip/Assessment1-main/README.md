# Welcome to your Expo app 👋
![image](https://github.com/user-attachments/assets/eb670595-ea0c-490e-9da7-3a2bf96a18a9)

#Login Page
![image](https://github.com/user-attachments/assets/ef4d6ba1-80b8-4860-9d83-7dc801a9c8ec)

#Register Page
![image](https://github.com/user-attachments/assets/33660089-1907-4871-8c41-0f0d40f5c519)

Forgot Password Page
![image](https://github.com/user-attachments/assets/9721ae90-74a8-4a9a-84d6-b37bcc97e57f)
